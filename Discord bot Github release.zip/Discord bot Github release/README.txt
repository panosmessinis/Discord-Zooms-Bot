Hi there, great to see you onboard this project make any changes to make this bot better,
I think if everyone contributes it will be 100 times better. The code is crap it's my first bot tho so eh... 
my contact details if you have any questions or any edits to make this bot better please do send me a message, trying to learn but also to test and experiment.
Email: panos@messinis.com
Discord: Doom#9033