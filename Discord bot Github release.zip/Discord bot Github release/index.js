const Discord = require('discord.js');
const bot = new Discord.Client();

const token = 'PUTTOKENHERE';

bot.on('ready', ()=>{
    console.log('(BOTNAME HERE) is now online!');
})

bot.on('message', msg=>{
   if(msg.content.toLowerCase() === 'teacher'){
       msg.reply('PMI:  Password: or just use the link: https://zoom.us/j/PUTPMIHERE?pwd=PUTPASSHERE')
   }
   if(msg.content.toLowerCase() === 'teacher2'){
    msg.reply('PMI:  Password: or just use the link: https://zoom.us/j/PUTPMIHERE?pwd=PUTPASSHERE')
}
if(msg.content.toLowerCase() === 'teacher3'){
    msg.reply('PMI:  Password: or just use the link: https://zoom.us/j/PUTPMIHERE?pwd=PUTPASSHERE')
}
if(msg.content.toLowerCase() === 'teacher4'){
    msg.reply('PMI:  Password: or just use the link: https://zoom.us/j/PUTPMIHERE?pwd=PUTPASSHERE')
}
if(msg.content.toLowerCase() === 'teacher5'){
    msg.reply('PMI:  Password: or just use the link: https://zoom.us/j/PUTPMIHERE?pwd=PUTPASSHERE')
}
if(msg.content.toLowerCase() === 'teacher6'){
    msg.reply('PMI:  Password: or just use the link: https://zoom.us/j/PUTPMIHERE?pwd=PUTPASSHERE')
}
if(msg.content.toLowerCase() === 'teacher7'){
    msg.reply('PMI:  Password: or just use the link: https://zoom.us/j/PUTPMIHERE?pwd=PUTPASSHERE')
}
if(msg.content.toLowerCase() === 'teacher8'){
    msg.reply('PMI:  Password: or just use the link: https://zoom.us/j/PUTPMIHERE?pwd=PUTPASSHERE')
}
if(msg.content.toLowerCase() === '.help'){
    msg.reply('Hi dear student, Type your teachers name with a capital starting letter and get their PMI and password or you can click on the link provided eg. Try TEACHER')
}
if(msg.content.toLowerCase() === 'are you a bot?'){
    msg.reply('Are you an idiot?')
}
})
bot.login(token);

